// create by 7七月@微信公众号 林间有风
const config = {
  api_blink_url: 'http://bl.7yue.pro/v1/',
  appkey: '访问www.7yue.pro获取appkey'
}

export { config }